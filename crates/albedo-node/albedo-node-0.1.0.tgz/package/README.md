# albedo-node

`albedo-node` is the N-API bridge crate for ALBEDO.

It exposes three baseline APIs:

- `analyzeProject(path, options)`
- `optimizeManifest(manifest, options)`
- `getCacheStats()`

## Build

```bash
cd crates/albedo-node
npm install
npm run build
```

The build emits a native `.node` artifact in this directory.

## Local Pack

```bash
cd crates/albedo-node
npm run pack:local
```

This creates an installable local tarball for integration testing.
